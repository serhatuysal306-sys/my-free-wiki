@echo off
chcp 65001 >nul
setlocal
title My Free Wiki - Kurulum
echo.
echo  === My Free Wiki kuruluyor ===
echo.
set "PYW="
where pythonw >nul 2>nul && set "PYW=pythonw"
if not defined PYW (
  where pyw >nul 2>nul && set "PYW=pyw"
)
if not defined PYW (
  echo Python bulunamadi. winget ile kuruluyor...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  echo.
  echo Python kuruldu. Lutfen bu pencereyi kapatip kur.bat dosyasina TEKRAR cift tiklayin.
  pause
  exit /b
)
set "DEST=%LOCALAPPDATA%\MyFreeWiki"
mkdir "%DEST%" 2>nul
copy /Y "%~dp0myfreewiki.py" "%DEST%\" >nul
if exist "%~dp0ornekler" xcopy /E /I /Y "%~dp0ornekler" "%DEST%\ornekler" >nul
for /f "delims=" %%i in ('where %PYW%') do (set "PYWPATH=%%i" & goto :got)
:got
reg add "HKCU\Software\Classes\.mfw" /ve /d MyFreeWiki.File /f >nul
reg add "HKCU\Software\Classes\MyFreeWiki.File\shell\open\command" /ve /d "\"%PYWPATH%\" \"%DEST%\myfreewiki.py\" \"%%1\"" /f >nul
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\My Free Wiki.lnk');$s.TargetPath='%PYWPATH%';$s.Arguments='\"%DEST%\myfreewiki.py\"';$s.WorkingDirectory='%DEST%';$s.Save()"
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Programs')+'\My Free Wiki.lnk');$s.TargetPath='%PYWPATH%';$s.Arguments='\"%DEST%\myfreewiki.py\"';$s.WorkingDirectory='%DEST%';$s.Save()"
echo.
echo  Kurulum tamam! Masaustunde "My Free Wiki" kisayolu olusturuldu.
echo  Acilinca .mfw dosyasini surukleyip birakin (ornek: %DEST%\ornekler\ataturk.mfw)
echo.
start "" "%PYWPATH%" "%DEST%\myfreewiki.py"
pause
