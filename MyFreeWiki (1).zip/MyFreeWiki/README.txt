MY FREE WIKI
============
Ücretsiz, internetsiz, kendi .mfw dosya formatıyla çalışan mini wiki. Masaüstü uygulamasıdır (kendi penceresi var, tarayıcı gerekmez). Python 3 + tkinter gerekir.

KURULUM
Windows : kur.bat dosyasına çift tıkla (Python yoksa winget ile kurar, masaüstüne kısayol koyar).
Pardus  : 1) myfreewiki_1.0_all.deb dosyasına çift tıkla -> Yükle   (en kolay, python3-tk'yi de kendisi kurar)
          2) ya da terminalde:  bash kur.sh
          3) ya da kurmadan:    python3 myfreewiki.py

KULLANIM
Uygulama ilk açıldığında boştur. "📂 .mfw dosyası aç" (Ctrl+O) ile dosyayı seç; kurulumdan sonra .mfw dosyasına çift tıklamak da açar. Ctrl+F aramaya gider.
Açılan wikiler kütüphanede (~/.myfreewiki) hatırlanır. Arama kutusu tüm wikilerde Türkçe karakter
duyarsız arar. ornekler/ataturk.mfw hazır örnektir.

.MFW FORMATI (JSON, UTF-8)
{ "format":"MyFreeWiki","version":1,"title":"Başlık","subtitle":"Alt başlık",
  "sections":[ {"id":"x","title":"Bölüm","lead":"Açıklama","type":"n",
     "items":[ {"title":"Madde","tag":"1881","text":"Paragraf1||Paragraf2","keywords":"ek arama kelimeleri"} ] } ] }
Bölüm tipleri: n=normal madde, q=söz {"text","note"}, y=zaman çizelgesi {"year","title","text","events":[..]},
f=soru-cevap (title=soru), g=A-Z sözlük.
