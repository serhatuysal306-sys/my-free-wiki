#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
My Free Wiki - kendi .mfw dosya formatiyla calisan, internetsiz, ucretsiz masaustu wiki.
Sadece Python 3 + tkinter kullanir (Windows'ta Python ile gelir, Pardus'ta python3-tk).

Kullanim:  python3 myfreewiki.py [dosya.mfw ...]
"""
import json, os, sys, shutil, re
import tkinter as tk
from tkinter import filedialog, messagebox

RED, DARK, BG, INK = "#c8102e", "#7a0a1c", "#faf6f1", "#222222"
MUTED, GOLD, LINE, CARD = "#666666", "#b8922f", "#e6dccf", "#ffffff"
HOME = os.path.join(os.path.expanduser("~"), ".myfreewiki")
LIB = os.path.join(HOME, "kutuphane")
CFG = os.path.join(HOME, "ayar.json")
os.makedirs(LIB, exist_ok=True)
WIN = sys.platform.startswith("win")
FAMILY = "Segoe UI" if WIN else "DejaVu Sans"

_TBL = str.maketrans({"ı": "i", "ç": "c", "ğ": "g", "ö": "o", "ş": "s", "ü": "u", "â": "a", "î": "i",
                      "û": "u", "İ": "i", "I": "i", "Ç": "c", "Ğ": "g", "Ö": "o", "Ş": "s", "Ü": "u"})


def fold(s):
    return str(s).translate(_TBL).lower()


def safe_name(name):
    name = os.path.basename(name)
    name = re.sub(r"[^\w.\- ]", "_", name, flags=re.UNICODE)
    return name if name.lower().endswith(".mfw") else name + ".mfw"


def read_mfw(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        d = json.load(f)
    if not isinstance(d, dict) or d.get("format") != "MyFreeWiki" or not isinstance(d.get("sections"), list):
        raise ValueError("Bu dosya bir My Free Wiki (.mfw) dosyası değil.")
    return d


def prepare(data, dosya):
    items = []
    for si, sec in enumerate(data["sections"]):
        typ = sec.get("type", "n")
        its = sec.get("items", [])
        if typ == "g":
            its.sort(key=lambda x: fold(x.get("title", "")))
        for ii, it in enumerate(its):
            o = {"si": si, "ii": ii, "sec": sec, "type": typ, "open": False,
                 "title": it.get("title") or it.get("text") or "", "tag": it.get("tag", ""),
                 "year": it.get("year", ""), "note": it.get("note", ""),
                 "events": it.get("events", [])}
            o["paras"] = [] if typ == "q" else str(it.get("text", "")).split("||")
            if typ == "q":
                o["title"] = it.get("text", "")
            o["idx"] = fold(" ".join([o["title"], o["tag"], o["year"], " ".join(o["paras"]),
                                      " ".join(o["events"]), o["note"], it.get("keywords", ""),
                                      sec.get("title", "")]))
            items.append(o)
    return {"dosya": dosya, "data": data, "items": items}


class App:
    def __init__(self, root, files):
        self.root = root
        self.wikis, self.cur, self.query = [], -1, ""
        self.act, self.toc_open, self.after_id = {}, set(), None
        self.fs = 12
        try:
            with open(CFG, "r", encoding="utf-8") as f:
                self.fs = max(9, min(24, int(json.load(f).get("fs", 12))))
        except Exception:
            pass
        root.title("My Free Wiki")
        root.geometry("1050x760")
        root.minsize(620, 480)
        root.configure(bg=BG)
        self.build_ui()
        self.load_library()
        for fpath in files:
            self.add_file(fpath, quiet=True)
        self.render()

    # ---------- arayuz ----------
    def build_ui(self):
        r = self.root
        hero = tk.Frame(r, bg=RED)
        hero.pack(fill="x")
        self.ttl = tk.Label(hero, text="My Free Wiki", bg=RED, fg="white", font=(FAMILY, 22, "bold"))
        self.ttl.pack(pady=(14, 0))
        self.sub = tk.Label(hero, text="", bg=RED, fg="#ffe3e6", font=(FAMILY, 10), wraplength=900)
        self.sub.pack()
        row = tk.Frame(hero, bg=RED)
        row.pack(pady=10, fill="x", padx=40)
        self.qvar = tk.StringVar()
        self.entry = tk.Entry(row, textvariable=self.qvar, font=(FAMILY, 13), relief="flat", bg="white",
                              fg=INK, insertbackground=INK, highlightthickness=8, highlightbackground="white",
                              highlightcolor="white")
        self.entry.pack(side="left", fill="x", expand=True)
        self.qvar.trace_add("write", lambda *a: self.schedule_search())
        tk.Button(row, text="✕", command=self.clear, relief="flat", bg="#eeeeee", fg="#333", width=3,
                  cursor="hand2").pack(side="left", padx=(6, 0))
        tk.Button(row, text="📂  .mfw dosyası aç", command=self.open_dialog, relief="flat", bg="white", fg=DARK,
                  font=(FAMILY, 10, "bold"), cursor="hand2", padx=12).pack(side="left", padx=(8, 0))
        self.chips = tk.Frame(hero, bg=RED)
        self.chips.pack()
        self.tabs = tk.Frame(hero, bg=RED)
        self.tabs.pack(pady=(2, 0))
        tools = tk.Frame(hero, bg=RED)
        tools.pack(pady=(4, 10))
        tk.Label(tools, text="Yazı boyutu:", bg=RED, fg="white", font=(FAMILY, 9)).pack(side="left")
        for txt, d in (("A−", -1), ("A+", 1)):
            tk.Button(tools, text=txt, command=lambda d=d: self.set_fs(self.fs + d), relief="flat",
                      bg="#d9475d", fg="white", cursor="hand2", width=4).pack(side="left", padx=3)
        self.rm_btn = tk.Button(tools, text="Bu wikiyi kaldır", command=self.remove_current, relief="flat",
                                bg="#d9475d", fg="white", cursor="hand2")
        self.rm_btn.pack(side="left", padx=(14, 0))

        self.nav = tk.Text(r, height=2, bg=DARK, fg="white", relief="flat", wrap="word", cursor="arrow",
                           font=(FAMILY, 10), padx=8, pady=4, highlightthickness=0, state="disabled")
        self.nav.tag_configure("navlink", foreground="white", spacing1=2, spacing3=2)
        self.nav.tag_bind("navlink", "<Enter>", lambda e: self.nav.config(cursor="hand2"))
        self.nav.tag_bind("navlink", "<Leave>", lambda e: self.nav.config(cursor="arrow"))
        self.nav.bind("<Button-1>", lambda e: self.click(e, self.nav))

        body = tk.Frame(r, bg=BG)
        body.pack(fill="both", expand=True)
        self.sb = tk.Scrollbar(body)
        self.sb.pack(side="right", fill="y")
        self.t = tk.Text(body, bg=BG, fg=INK, relief="flat", wrap="word", cursor="arrow", padx=14, pady=8,
                         highlightthickness=0, yscrollcommand=self.sb.set, state="disabled", spacing2=3)
        self.t.pack(side="left", fill="both", expand=True)
        self.sb.config(command=self.t.yview)
        self.t.bind("<Button-1>", lambda e: self.click(e, self.t))
        self.config_tags()
        r.bind("<Control-o>", lambda e: self.open_dialog())
        r.bind("<Control-f>", lambda e: (self.entry.focus_set(), self.entry.select_range(0, "end")))
        r.bind("<Escape>", lambda e: self.clear())
        self.entry.focus_set()

    def config_tags(self):
        t, fs = self.t, self.fs
        F = lambda sz=0, st="": (FAMILY, fs + sz, st) if st else (FAMILY, fs + sz)
        t.tag_configure("h2", font=F(5, "bold"), foreground=DARK, spacing1=22, spacing3=2, lmargin1=4, lmargin2=4)
        t.tag_configure("lead", font=F(-1), foreground=MUTED, lmargin1=4, lmargin2=4, spacing3=6)
        t.tag_configure("card", background=CARD)
        t.tag_configure("chead", lmargin1=12, lmargin2=34, spacing1=6)
        t.tag_configure("cpara", lmargin1=34, lmargin2=34, rmargin=12, spacing3=3)
        t.tag_configure("cend", spacing3=4)
        t.tag_configure("bar", foreground=RED, font=F(2, "bold"))
        t.tag_configure("gbar", foreground=GOLD, font=F(2, "bold"))
        t.tag_configure("title", font=F(1, "bold"), foreground=DARK)
        t.tag_configure("badge", background=GOLD, foreground="white", font=F(-2, "bold"))
        t.tag_configure("small", font=F(-3), foreground=MUTED, background=CARD)
        t.tag_configure("quote", font=F(0, "italic"))
        t.tag_configure("cite", font=F(-1), foreground=MUTED)
        t.tag_configure("gap", font=(FAMILY, 4), background=BG)
        t.tag_configure("letter", font=F(4, "bold"), foreground="white", background=RED, spacing1=12, spacing3=4)
        t.tag_configure("lbtn", foreground=DARK, font=F(1, "bold"), background=CARD, relief="solid", borderwidth=1)
        t.tag_configure("ybtn", foreground="white", background=GOLD, font=F(-1, "bold"))
        t.tag_configure("tochead", font=F(1, "bold"), foreground=DARK, background=CARD, lmargin1=8, lmargin2=8,
                        spacing1=4, spacing3=4)
        t.tag_configure("toclink", foreground=INK, background="#fbf8f3", font=F(-1), underline=True)
        t.tag_configure("center", justify="center")
        t.tag_configure("big", font=F(8, "bold"), foreground=DARK)
        t.tag_configure("muted", foreground=MUTED)
        t.tag_configure("link")
        t.tag_configure("hl", background="#ffe066", foreground="#000000")
        t.tag_raise("hl")
        t.tag_bind("link", "<Enter>", lambda e: t.config(cursor="hand2"))
        t.tag_bind("link", "<Leave>", lambda e: t.config(cursor="arrow"))

    def set_fs(self, v):
        self.fs = max(9, min(24, v))
        try:
            with open(CFG, "w", encoding="utf-8") as f:
                json.dump({"fs": self.fs}, f)
        except Exception:
            pass
        self.config_tags()
        self.render(keep=True)

    # ---------- kutuphane ----------
    def load_library(self):
        for n in sorted(os.listdir(LIB)):
            if n.lower().endswith(".mfw"):
                try:
                    self.wikis.append(prepare(read_mfw(os.path.join(LIB, n)), n))
                except Exception:
                    pass
        if self.wikis:
            self.cur = 0

    def add_file(self, path, quiet=False):
        try:
            data = read_mfw(path)
        except Exception as e:
            if not quiet:
                messagebox.showerror("Açılamadı", "%s\n\n%s" % (os.path.basename(path), e))
            return
        name = safe_name(path)
        try:
            shutil.copyfile(path, os.path.join(LIB, name))
        except shutil.SameFileError:
            pass
        self.wikis = [w for w in self.wikis if w["dosya"] != name]
        self.wikis.append(prepare(data, name))
        self.cur = len(self.wikis) - 1

    def open_dialog(self):
        paths = filedialog.askopenfilenames(title="My Free Wiki dosyası seç",
                                            filetypes=[("My Free Wiki", "*.mfw"), ("Tüm dosyalar", "*.*")])
        for p in paths:
            self.add_file(p)
        if paths:
            self.qvar.set("")
            self.render()

    def remove_current(self):
        if self.cur < 0:
            return
        w = self.wikis[self.cur]
        if messagebox.askyesno("Kaldır", "“%s” kütüphaneden kaldırılsın mı?\n(Orijinal dosyanız silinmez.)" %
                                         w["data"].get("title", w["dosya"])):
            try:
                os.remove(os.path.join(LIB, w["dosya"]))
            except OSError:
                pass
            del self.wikis[self.cur]
            self.cur = min(self.cur, len(self.wikis) - 1)
            self.render()

    # ---------- arama ----------
    def schedule_search(self):
        if self.after_id:
            self.root.after_cancel(self.after_id)
        self.after_id = self.root.after(200, self.do_search)

    def do_search(self):
        self.after_id = None
        q = self.qvar.get().strip()
        if q != self.query:
            self.query = q
            self.render()
            self.t.yview_moveto(0)

    def clear(self):
        self.qvar.set("")
        self.query = ""
        self.render()

    # ---------- yardimcilar ----------
    def w(self, txt, *tags):
        self.t.insert("end", txt, tags)

    def wh(self, txt, words, *tags):
        if not words:
            return self.w(txt, *tags)
        f = fold(txt)
        if len(f) != len(txt):
            return self.w(txt, *tags)
        rng = []
        for wd in words:
            p = 0
            while True:
                p = f.find(wd, p)
                if p < 0:
                    break
                rng.append((p, p + len(wd)))
                p += len(wd)
        if not rng:
            return self.w(txt, *tags)
        rng.sort()
        merged = [list(rng[0])]
        for a, b in rng[1:]:
            if a <= merged[-1][1]:
                merged[-1][1] = max(merged[-1][1], b)
            else:
                merged.append([a, b])
        pos = 0
        for a, b in merged:
            if a > pos:
                self.w(txt[pos:a], *tags)
            self.w(txt[a:b], *(tags + ("hl",)))
            pos = b
        if pos < len(txt):
            self.w(txt[pos:], *tags)

    def link(self, fn):
        name = "act%d" % len(self.act)
        self.act[name] = fn
        self.t.tag_configure(name)
        return name

    def click(self, e, widget):
        try:
            idx = widget.index("@%d,%d" % (e.x, e.y))
        except tk.TclError:
            return
        for n in widget.tag_names(idx):
            if n in self.act:
                self.act[n]()
                return

    def mark(self, name):
        self.t.mark_set(name, "end-1c")
        self.t.mark_gravity(name, "left")

    def goto_mark(self, name):
        self.t.update_idletasks()
        try:
            self.t.yview(name)
        except tk.TclError:
            pass

    def toggle_year(self, o):
        o["open"] = not o["open"]
        self.render(keep=True)

    def goto_item(self, o):
        if o["type"] == "y" and not o["open"]:
            o["open"] = True
            self.render(keep=True)
        self.goto_mark("m%d_%d" % (o["si"], o["ii"]))

    # ---------- cizim ----------
    def header_for(self):
        for wd in self.chips.winfo_children():
            wd.destroy()
        for wd in self.tabs.winfo_children():
            wd.destroy()
        for i, wk in enumerate(self.wikis):
            on = (i == self.cur)
            tk.Button(self.tabs, text=wk["data"].get("title", wk["dosya"]), relief="flat", cursor="hand2",
                      bg="white" if on else "#d9475d", fg=DARK if on else "white",
                      font=(FAMILY, 9, "bold" if on else "normal"),
                      command=lambda i=i: self.select(i)).pack(side="left", padx=3, pady=2)
        if self.cur >= 0:
            wk = self.wikis[self.cur]
            self.ttl.config(text=wk["data"].get("title", wk["dosya"]))
            self.sub.config(text=wk["data"].get("subtitle", ""))
            for s in wk["data"].get("suggest", [])[:14]:
                tk.Button(self.chips, text=s, relief="flat", cursor="hand2", bg="#d9475d", fg="white",
                          font=(FAMILY, 9), command=lambda s=s: self.qvar.set(s)).pack(side="left", padx=2, pady=2)
            self.rm_btn.pack(side="left", padx=(14, 0))
        else:
            self.ttl.config(text="My Free Wiki")
            self.sub.config(text="Kendi dosya formatıyla çalışan ücretsiz, internetsiz mini wiki")
            self.rm_btn.pack_forget()

    def select(self, i):
        self.cur = i
        self.qvar.set("")
        self.query = ""
        self.render()
        self.t.yview_moveto(0)

    def render(self, keep=False):
        t = self.t
        y = t.yview()[0]
        self.header_for()
        t.config(state="normal")
        t.delete("1.0", "end")
        for m in list(t.mark_names()):
            if m.startswith(("m", "s")) and m not in ("insert", "current"):
                t.mark_unset(m)
        self.act = {}
        for n in t.tag_names():
            if n.startswith("act"):
                t.tag_delete(n)
        words = fold(self.query).split() if self.query else []
        self.nav.config(state="normal")
        self.nav.delete("1.0", "end")
        self.nav.config(state="disabled")
        self.nav.pack_forget()
        if self.cur < 0:
            self.render_empty()
        elif words:
            self.render_search(words)
        else:
            self.render_wiki(self.wikis[self.cur])
        t.config(state="disabled")
        if keep:
            t.yview_moveto(y)

    def render_empty(self):
        t = self.t
        self.w("\n\n\n", "center")
        self.w("Henüz bir wiki açılmadı\n\n", "center", "big")
        self.w("Bir .mfw dosyası açarak başlayın.\n\n", "center", "muted")
        b = tk.Button(t, text="📂  .mfw dosyası aç", command=self.open_dialog, relief="flat", bg=RED, fg="white",
                      font=(FAMILY, 13, "bold"), cursor="hand2", padx=22, pady=10)
        t.window_create("end", window=b)
        self.w("\n\n", "center")
        self.w("Örnek dosya: ornekler/ataturk.mfw", "center", "muted")
        self.w("\n")

    def build_nav(self, wk):
        n = self.nav
        n.pack(fill="x", before=self.t.master)
        n.config(state="normal")
        for si, sec in enumerate(wk["data"]["sections"]):
            tag = "nv%d" % si
            n.tag_configure(tag)
            self.act[tag] = (lambda si=si: self.goto_mark("s%d" % si))
            n.insert("end", " %s " % sec.get("title", ""), ("navlink", tag))
            n.insert("end", " ")
        n.config(state="disabled")
        n.tag_raise("navlink")

    def render_wiki(self, wk):
        self.build_nav(wk)
        for si, sec in enumerate(wk["data"]["sections"]):
            typ = sec.get("type", "n")
            self.mark("s%d" % si)
            self.w("\n" if si else "", "gap")
            self.w(sec.get("title", "") + "\n", "h2")
            fr = tk.Frame(self.t, bg=RED, height=3, width=980)
            self.t.window_create("end", window=fr)
            self.w("\n")
            if sec.get("lead"):
                self.w(sec["lead"] + "\n", "lead")
            its = [o for o in wk["items"] if o["si"] == si]
            if typ == "y" and its:
                for o in its:
                    ln = self.link(lambda o=o: self.goto_item(o))
                    self.w(" %s " % o["year"], "ybtn", "link", ln)
                    self.w(" ")
                self.w("\n", "gap")
            if its and typ != "q" and typ != "g":
                key = (wk["dosya"], si)
                ln = self.link(lambda key=key: (self.toc_open.symmetric_difference_update({key}),
                                                self.render(keep=True)))
                is_open = key in self.toc_open
                self.w("%s Bu bölümdeki başlıklar (%d)\n" % ("▾" if is_open else "▸", len(its)),
                       "tochead", "link", ln)
                if is_open:
                    for o in its:
                        ln2 = self.link(lambda o=o: self.goto_item(o))
                        lab = ("%s – %s" % (o["year"], o["title"])) if typ == "y" else o["title"]
                        self.w(" %s " % lab, "toclink", "link", ln2)
                        self.w("  ")
                    self.w("\n", "cend")
            if typ == "g" and its:
                letters = "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ"
                have = {}
                for o in its:
                    L = o["title"][:1]
                    L = "İ" if L == "i" else ("I" if L == "ı" else L.upper())
                    have.setdefault(L, None)
                for c in letters:
                    if c in have:
                        ln = self.link(lambda c=c: self.goto_mark("l%d_%s" % (si, c)))
                        self.w(" %s " % c, "lbtn", "link", ln)
                    else:
                        self.w(" %s " % c, "muted")
                    self.w(" ")
                self.w("\n", "gap")
            prev = ""
            for o in its:
                if typ == "g":
                    L = o["title"][:1]
                    L = "İ" if L == "i" else ("I" if L == "ı" else L.upper())
                    if L != prev:
                        self.mark("l%d_%s" % (si, L))
                        self.w("  %s  " % L, "letter")
                        self.w("\n", "gap")
                        prev = L
                self.draw_item(o, [])

    def draw_item(self, o, words, show_sec=False):
        self.mark("m%d_%d" % (o["si"], o["ii"]))
        typ = o["type"]
        if typ == "q":
            self.w("▌ ", "card", "gbar", "chead")
            self.wh("“%s”" % o["title"], words, "card", "quote", "chead")
            self.w("\n", "card", "chead")
            if o["note"]:
                self.wh("— " + o["note"], words, "card", "cite", "cpara")
                self.w("\n", "card", "cpara")
            self.w("\n", "gap")
            return
        if typ == "y":
            ln = self.link(lambda o=o: self.toggle_year(o))
            opened = o["open"] or bool(words)
            self.w("▌ ", "card", "gbar", "chead", "link", ln)
            self.w(" %s " % o["year"], "badge", "link", ln)
            self.w(" ", "card", "link", ln)
            self.wh(o["title"], words, "card", "title", "link", ln)
            self.w("   " + ("▴" if opened else "▾"), "card", "muted", "link", ln)
            if show_sec:
                self.w("   · " + o["sec"].get("title", ""), "small")
            self.w("\n", "card", "chead", "link", ln)
            if opened:
                for p in o["paras"]:
                    self.wh(p, words, "card", "cpara")
                    self.w("\n", "card", "cpara")
                for ev in o["events"]:
                    self.wh("•  " + ev, words, "card", "cpara")
                    self.w("\n", "card", "cpara")
            self.w("\n", "gap")
            return
        self.w("▌ ", "card", "bar", "chead")
        if o["tag"]:
            self.w(" %s " % o["tag"], "badge")
            self.w(" ", "card")
        pre = "S: " if typ == "f" else ""
        self.wh(pre + o["title"], words, "card", "title", "chead")
        if show_sec:
            self.w("   · " + o["sec"].get("title", ""), "small")
        self.w("\n", "card", "chead")
        for p in o["paras"]:
            if p.strip():
                self.wh(p, words, "card", "cpara")
                self.w("\n", "card", "cpara")
        self.w("\n", "gap")

    def render_search(self, words):
        total = 0
        blocks = []
        for wk in self.wikis:
            hits = [o for o in wk["items"] if all(w in o["idx"] for w in words)]
            if hits:
                blocks.append((wk, hits))
                total += len(hits)
        self.w("%s sonuç bulundu: “%s”\n" % (total, self.query) if total else "", "lead")
        if not total:
            self.w("\n\nSonuç bulunamadı\n", "center", "big")
            self.w("Başka bir kelime deneyin ya da yazım şeklini değiştirin.\n", "center", "muted")
            return
        for wk, hits in blocks:
            self.w("%s (%d)\n" % (wk["data"].get("title", wk["dosya"]), len(hits)), "h2")
            for o in hits[:300]:
                self.draw_item(o, words, show_sec=True)
            if len(hits) > 300:
                self.w("… ve %d sonuç daha. Aramayı daraltın.\n" % (len(hits) - 300), "lead")


def main():
    try:
        if WIN:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    App(root, [a for a in sys.argv[1:] if os.path.isfile(a)])
    root.mainloop()


if __name__ == "__main__":
    main()
