#!/usr/bin/env bash
# My Free Wiki - Pardus / Linux tek tikla kurulum
set -e
cd "$(dirname "$(readlink -f "$0")")"
if ! command -v python3 >/dev/null; then
  echo "python3 bulunamadi. Kuruluyor (sudo sifresi istenebilir)..."
  sudo apt-get install -y python3
fi
DEST="$HOME/.local/share/myfreewiki"
if ! python3 -c "import tkinter" 2>/dev/null; then
  echo "python3-tk kuruluyor (sudo sifresi istenebilir)..."
  sudo apt-get install -y python3-tk
fi
mkdir -p "$DEST" "$HOME/.local/share/applications"
cp myfreewiki.py "$DEST/"
[ -d ornekler ] && cp -r ornekler "$DEST/"
chmod +x "$DEST/myfreewiki.py"
cat > "$HOME/.local/share/applications/myfreewiki.desktop" <<D
[Desktop Entry]
Type=Application
Name=My Free Wiki
Comment=Ücretsiz çevrimdışı mini wiki
Exec=python3 $DEST/myfreewiki.py %f
Icon=accessories-dictionary
Terminal=false
Categories=Education;Office;
MimeType=application/x-myfreewiki;
D
mkdir -p "$HOME/.local/share/mime/packages"
cat > "$HOME/.local/share/mime/packages/myfreewiki.xml" <<D
<?xml version="1.0" encoding="UTF-8"?>
<mime-info xmlns="http://www.freedesktop.org/standards/shared-mime-info">
 <mime-type type="application/x-myfreewiki"><comment>My Free Wiki dosyası</comment><glob pattern="*.mfw"/></mime-type>
</mime-info>
D
update-mime-database "$HOME/.local/share/mime" 2>/dev/null || true
update-desktop-database "$HOME/.local/share/applications" 2>/dev/null || true
DESK="$(xdg-user-dir DESKTOP 2>/dev/null || echo "$HOME/Masaüstü")"
if [ -d "$DESK" ]; then cp "$HOME/.local/share/applications/myfreewiki.desktop" "$DESK/"; chmod +x "$DESK"/myfreewiki.desktop; gio set "$DESK/myfreewiki.desktop" metadata::trusted true 2>/dev/null || true; fi
echo "Kurulum tamam! Uygulama menüsünde ve masaüstünde 'My Free Wiki' var."
echo "Örnek dosya: $DEST/ornekler/ataturk.mfw"
nohup python3 "$DEST/myfreewiki.py" >/dev/null 2>&1 &
